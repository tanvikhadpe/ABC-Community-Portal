package com.lithan.controller;

import com.lithan.dao.UserDao;
import com.lithan.dao.UserDaoImpl;
import com.lithan.model.User;
import com.opensymphony.xwork2.ActionSupport;

public class RegisterAction extends ActionSupport
{
	User user=new User();
	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	public void validate() {  
	    if(user.getFname().length()<1)  
	    {   addFieldError("fname","Please enter your name."); 
	    	//	System.out.println("please enter your name");
	    }
	    
	    if(user.getEmail().length()<1)  
	        addFieldError("email","Please enter your Email Id."); 
	    
	    if(user.getCity().length()<1)  
	        addFieldError("city","Please enter the city you currently reside in."); 
	    
	    if(user.getProfession().length()<1)  
	        addFieldError("profession","Please specify your profession."); 
	    
	    if(user.getQualification().length()<1)  
	        addFieldError("qualification","Please specify your recent-most qualification."); 
	    
	    if(user.getContact().length()<1) {  
	        addFieldError("contact","Please enter your contact number.");}
	    else if (user.getContact().length()!=10) {
	         addFieldError("contact", "Please enter a valid contact number.");}; 
	    
	    if(user.getPassword().length()<6)  
	        addFieldError("password","Password must be greater than 5 characters.");  
		}  
	
	@Override
	public String execute() throws Exception {
		UserDao dao=new UserDaoImpl();
		boolean result=dao.addUser(user);
		if(result)
			return SUCCESS;
		else
			return ERROR;
	}
}
