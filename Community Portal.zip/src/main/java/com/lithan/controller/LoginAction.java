package com.lithan.controller;

import com.lithan.dao.UserDao;
import com.lithan.dao.UserDaoImpl;
import com.lithan.model.User;
import com.opensymphony.xwork2.ActionSupport;
import java.util.Map;
import org.apache.struts2.dispatcher.SessionMap;  
import org.apache.struts2.interceptor.SessionAware;  

public class LoginAction implements SessionAware
{
	private SessionMap<String,Object> sessionMap;
	
	User user=new User();
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public void setSession(Map<String, Object> map) {
		
		sessionMap=(SessionMap)map;
	}
	
	public String execute() throws Exception {
		UserDao dao=new UserDaoImpl();
		user=dao.validateUser(user.getEmail(), user.getPassword());
		System.out.println(user.getStatus());
		if(user.getStatus()==1)
		{
			return "success";
			}
			
			else if(user.getStatus()==0)		{
			sessionMap.put("login","true");   
			sessionMap.put("fname",user.getFname());
			sessionMap.put("city",user.getCity());
			sessionMap.put("email",user.getEmail());
			sessionMap.put("contact",user.getContact());
			sessionMap.put("profession",user.getProfession());
			sessionMap.put("qualification",user.getQualification());
			sessionMap.put("experience",user.getExperience());
		    return "home";  
		}
		else {
			return "login";}
	}

public String logout() {
	if (sessionMap!=null) {
		sessionMap.invalidate();
	}
	return "success";
}
}

