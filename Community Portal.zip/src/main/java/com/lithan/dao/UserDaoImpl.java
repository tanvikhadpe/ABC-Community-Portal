package com.lithan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lithan.config.DBConfig;
import com.lithan.model.User;

public class UserDaoImpl implements UserDao{

	Connection con=null;
	public User validateUser(String email, String password) {
			con=DBConfig.getConnection();
			System.out.println("Connection Established");
			User s=null;
			String query="select * from user where email=? and password=?";
			try {
				PreparedStatement stmt=con.prepareStatement(query);
				stmt.setString(1, email);
				stmt.setString(2, password);
				
				ResultSet result=stmt.executeQuery();
				
				while(result.next())
				{
					s=new User();
					s.setFname(result.getString(2));
					s.setCity(result.getString(4));
					s.setEmail(result.getString(3));
					s.setContact(result.getString(5));
					s.setProfession(result.getString(6));
					s.setQualification(result.getString(7));
					s.setExperience(result.getString(9));
					s.setStatus(result.getInt(10));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			return s;
	}

	public List<User> getByName(String search) {
		con=DBConfig.getConnection();
		User s=null;
		List<User> list = new ArrayList<User>();
		System.out.println(search);
		String query="select * from user where fname like \""+search+"\" or city like \""+search+"\"or profession like \""+search+"\"or email like \""+search+"\"or qualification like \""+search+"\"or experience like \""+search+"\"";
    System.out.println(query);
		try {
			PreparedStatement stmt=con.prepareStatement(query);
			
			ResultSet result=stmt.executeQuery();
			System.out.println(result);
			while(result.next())
			{
				s=new User();
				s.setFname(result.getString(2));
				s.setEmail(result.getString(3));
				s.setCity(result.getString(4));
				s.setProfession(result.getString(6));
				list.add(s);			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return list;
}
	
	public User frgpswd(String emailcheck) {

		con = DBConfig.getConnection();
		User s=null;
		// List<User> list = new ArrayList<User>();
		String query ="SELECT * FROM user where email=?";
		try{
		PreparedStatement pst=con.prepareStatement(query);
		pst.setString(1, emailcheck);

		ResultSet result = pst.executeQuery();
		while (result.next()) {
		{
		s=new User();
		s.setEmail(result.getString(3));
		}

		}
		}
		catch(SQLException e) {
		e.printStackTrace();

		}
		return s;
		}

	public boolean updtpswd(User user) {
		boolean flag = false;
		con = DBConfig.getConnection();
		try{
		PreparedStatement pst=con.prepareStatement
		("update user set password = ? where email = ?");

		pst.setString(1, user.getPassword());
		pst.setString(2, user.getEmail());

		int x=pst.executeUpdate();
		if(x>0)
		flag=true;
		} catch (Exception e) {
		e.printStackTrace();
		}
		return flag;
		}
			
	public boolean addUser(User user) {
		boolean flag=false;
		con=DBConfig.getConnection();
		System.out.println("Connection established");
		try{
			PreparedStatement pst=con.prepareStatement
					("insert into user (fname, email, city, contact, "
							+ "profession, qualification, password, experience) "
							+ "values (?,?,?,?,?,?,?,?)");
			pst.setString(1, user.getFname());
			pst.setString(2, user.getEmail());
			pst.setString(3, user.getCity());
			pst.setString(4, user.getContact());
			pst.setString(5, user.getProfession());
			pst.setString(6, user.getQualification());
			pst.setString(7, user.getPassword());
			pst.setString(8, user.getExperience());
			System.out.println("Values are fetched for user "+user.getFname());
			int x=pst.executeUpdate();
			if(x>0)
				flag=true;
			System.out.println("Execute Update returned true for "+user.getFname());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public List<User> getByName() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean UpdUser(User user) {
		boolean flag=false;
		con=DBConfig.getConnection();
		System.out.println("Connection established");
		try{
			PreparedStatement pst=con.prepareStatement("update user set fname=?, city=?, contact=?, profession=?, qualification=?, experience=? where email = ?");
			pst.setString(1, user.getFname());
			pst.setString(2, user.getCity());
			pst.setString(3, user.getContact());
			pst.setString(4, user.getProfession());
			pst.setString(5, user.getQualification());
			pst.setString(6, user.getExperience());
			pst.setString(7, user.getEmail());
			
		
			int x=pst.executeUpdate();
			if(x>0)
				flag=true;
			System.out.println("updated");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
		
	public List<User> getAll() {
		con=DBConfig.getConnection();
		User s=null;
		List<User> list = new ArrayList<User>();
		String query="select * from user";
	
		try {
			PreparedStatement stmt=con.prepareStatement(query);
			
			
			ResultSet result=stmt.executeQuery();
			
			while(result.next())
			{
				s=new User();
				s.setFname(result.getString(2));
				s.setPassword(result.getString(8));
				s.setEmail(result.getString(3));
				s.setContact(result.getString(5));
				list.add(s);			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return list;
	}
	
	public int deleteUserDetails(String email) {
	con=DBConfig.getConnection();
	int i = 0;
	try {
	String sql = "delete from user where email=?";
	PreparedStatement stmt=con.prepareStatement(sql);
	stmt.setString(1, email);
	i = stmt.executeUpdate();
	return i;
	} catch (Exception e) {
	e.printStackTrace();
	return 0;
	}
	}
	
	public User getViewUsers(String email) {
		con=DBConfig.getConnection();
		//int i = 0;
		User s= null;
		try {
		String sql = "select * from user where email=?";
		PreparedStatement stmt=con.prepareStatement(sql);
		stmt.setString(1, email);
		
		ResultSet result=stmt.executeQuery();
		if(result.next())
		{
			s=new User();
			s.setFname(result.getString(2));
			s.setEmail(result.getString(3));
			s.setCity(result.getString(4));
			s.setProfession(result.getString(6));
			s.setQualification(result.getString(7));
			s.setExperience(result.getString(9));
			s.setContact(result.getString(5));}
		
		//i = stmt.executeUpdate();
		
		} catch (Exception e) {
		e.printStackTrace();
		}
		System.out.println(s);
		return s;
		}

	
}

