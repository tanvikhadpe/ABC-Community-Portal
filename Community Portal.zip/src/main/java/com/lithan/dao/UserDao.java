package com.lithan.dao;

import java.util.List;

import com.lithan.model.User;

public interface UserDao {

	public User validateUser(String email,String password);
	public List<User> getByName(String search);
	public boolean addUser(User user);
	public User frgpswd(String email);
	public boolean updtpswd(User user);
	public List<User> getAll();
	public int deleteUserDetails(String email);
	public boolean UpdUser(User user);
	public User getViewUsers(String email);
}
