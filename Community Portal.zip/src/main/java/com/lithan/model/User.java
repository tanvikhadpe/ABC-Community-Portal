package com.lithan.model;

public class User {

	private String fname;
	private String email;
	private String city;
	private String contact;
	private String profession;
	private String qualification;
	private String password;
	private String experience;
	private int status;
	public User()
	{
		
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public User(String fname, String email, String city, String contact, 
			String profession, String qualification, String password, 
			String experience, int status) {
		this.fname = fname;
		this.email = email;
		this.city = city;
		this.contact = contact;
		this.profession = profession;
		this.qualification = qualification;
		this.password = password;
		this.experience = experience;
		this.status = status;
	}
	public String getFname() {
		return fname;
	}
	
	public void setFname(String fname) {
		this.fname = fname;
	}
	
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	
	
	public String getProfession() {
		return profession;
	}
	public void setProfession(String profession) {
		this.profession = profession;
	}
	
	
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	@Override
	public String toString() {
		return "User [fname=" + fname + ", email=" + email + ", city=" + city + ", contact=" + contact + ", profession="
				+ profession + ", qualification=" + qualification + ", password=" + password + ", experience="
				+ experience + ", status=" + status + "]";
	}
	
}