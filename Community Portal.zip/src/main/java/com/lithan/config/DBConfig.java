package com.lithan.config;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConfig {

public static Connection getConnection()
{
Connection conn=null;

String driver="com.mysql.cj.jdbc.Driver";
String url="jdbc:mysql://projects.lithan.net:3306/inc0208?useTimezone=true&serverTimezone=UTC";
String user="INC0208";
String pass="INC0208";
//String url="jdbc:mysql://localhost:3306/abccommunity";
//String user="root";
//String pass="Tanvi@123";
try {
Class.forName(driver);
conn=DriverManager.getConnection(url,user,pass);
} catch (Exception e) {
e.printStackTrace();
}

return conn;
}
}