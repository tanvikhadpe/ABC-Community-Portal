package com.lithan.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class RegisterActionTest {

	@Test
	void testGetUser() {
		System.out.println("Test Sucessful.");
	}

	@Test
	void testSetUser() {
		System.out.println("Test Sucessful.");
	}

	@Test
	void testExecute() {
		System.out.println("Test Sucessful.");
	}

}
